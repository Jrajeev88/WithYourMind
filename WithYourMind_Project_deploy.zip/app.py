# ─────────────────────────────────────────────────────────────
# WithYourMind Hugging Face Spaces - Main App
# (Paste the full app.py code you received earlier below this line)
# ─────────────────────────────────────────────────────────────
# NOTE: Replace "YOUR_LORA_ADAPTER_PATH_OR_HF_REPO" with your actual LoRA adapter location

# <PASTE YOUR FULL APP CODE HERE>
